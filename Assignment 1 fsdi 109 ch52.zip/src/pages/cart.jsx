import "./styles/cart.css"

function Cart(){
    return(
        <div className="cart page">
            <h1>Ready to finalize the order?</h1>
            <h3>You are 1-clicl away from your products</h3>
        </div>
    );
}

export default Cart