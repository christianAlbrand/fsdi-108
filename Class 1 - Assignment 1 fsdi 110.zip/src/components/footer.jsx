import "./styles/footer.css"

function Footer(){
    return(
        <div className="footer">
            <footer className="footer-content">
                <div>
                    <span>Created by: Christian Albrand Aguirre</span>
                </div>
            </footer>
        </div>
    );
}

export default Footer;