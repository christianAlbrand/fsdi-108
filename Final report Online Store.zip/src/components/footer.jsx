import "./styles/footer.css"

function Footer(){
    return(
        <div className="footer_container">
            <h2 className="owner_name">Created by: Christian Albrand Aguirre</h2>
        </div>
    );
}

export default Footer;